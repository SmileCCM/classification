# chinese-text-classification
这份工程代码是CSDN博客：《[Python中文文本分类](http://blog.csdn.net/github_36326955/article/details/54891204)》的源代码.

其中，master分支是python3.6

python2.7的代码请到python2.7分支


这里仅仅为里演示代码原理，
因此只方进去原始数据集的一小部分，完成的数据集请到下面的链接里下载：



训练集

http://download.csdn.net/download/github_36326955/9747927

测试集

http://download.cs


如果你有任何的问题，请在本项目github主页中的issues栏中提出，或者方位上面的博客地址，在下方评论处发布问题。

step1: corpus_segment.py

step2: corpus2Bunch.py
请自觉创建目录train_word_bag和test_word_bag

step3: TFIDF_space.py

step4:NBayes_Predict.py

如果你觉得很棒棒，也许可以打个赏？
手机扫一扫：

<img src="http://img.blog.csdn.net/20170206162513453?watermark/2/text/aHR0cDovL2Jsb2cuY3Nkbi5uZXQvZ2l0aHViXzM2MzI2OTU1/font/5a6L5L2T/fontsize/400/fill/I0JBQkFCMA==/dissolve/70/gravity/Center" width=300 height=400 >
